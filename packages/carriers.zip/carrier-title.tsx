import { Button, HStack, Image, Text } from 'scripting'
import { providerNames, providerIds } from './hub'
import { identities } from './carrier-design'
import { CarrierNextIntent } from './app_intents'
import type { Ctx } from './mobile/ui'
/** The original top-left carrier name is the only switch target. */
export function CarrierTitle({ctx}:{ctx:Ctx}){
 const provider=ctx.carrier?.provider||'cmcc'
 const body=<HStack spacing={5} frame={{minHeight:44}}>
  {provider==='cmcc'?<Image imageUrl="https://raw.githubusercontent.com/MaYIHEI/pin/refs/heads/main/app/cmcc.png" resizable frame={{width:16,height:16}}/>:<Image systemName={identities[provider].symbol} font={14} foregroundStyle={identities[provider].ink as any}/>}
  <Text font={12} fontWeight="semibold" foregroundStyle={ctx.th.t1} lineLimit={1}>{providerNames[provider]}</Text>
  <Image systemName="arrow.triangle.2.circlepath" font={9} foregroundStyle={ctx.th.t3}/>
 </HStack>
 if(ctx.inApp)return <Button action={ctx.onCarrierChange||(()=>{})} buttonStyle="plain">{body}</Button>
 return <Button intent={CarrierNextIntent({current:provider,available:providerIds})} buttonStyle="plain">{body}</Button>
}
